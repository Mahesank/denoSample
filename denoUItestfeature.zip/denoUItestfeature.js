import puppeteer from "https://deno.land/x/puppeteer@16.2.0/mod.ts";
import { assertEquals, assertNotEquals, assertStringIncludes } from 'https://deno.land/std@0.79.0/testing/asserts.ts'


/**
     * Scenario: UI Validation for Login Page
     * When User logs in to the home page
     * Then valid UI elmements present in the login page
     **/

Deno.test('UI Login Screen', async _test => {
    const browser = await puppeteer.launch({ headless: false, slowMo: 80, args: ['–start-fullscreen']
});
    try {
        
        //Open the login page and enter Name and Password for admin
        const page = await browser.newPage();
        //await page.setViewport({ width: 1200, height: 1200 });
        await page.goto("https://textileblock-turtlenewton-8080.codio-box.uk/");
       // const screenshot = await page.screenshot({ path: "LoginUI.png" }); 

    // Assert if the User Name is displayed
    await assertEquals((await isElementVisible(page, '//label[text()="Username"]')),true,'UserName Lable Not Displayed'); // true
    
    // Assert if the Password is displayed
    await assertEquals((await isElementVisible(page, '//label[text()="Password"]')),true,'Password Lable Not Displayed'); // true
    
     // Assert if the Register is displayed
     await assertEquals((await isElementVisible(page, '//a[text()="Register"]')),true,'Register Lable Not Displayed'); // true
     
         
     }
    catch (error) {
        console.log(error);
    }
    finally {
        await browser.close();
    }
})


/**
     * Scenario: UI Validation for product Upload
     * When User logs in to the home page
     * Then valid UI elmements present in the login page
     **/
Deno.test('Product Screen', async _test => {
    const browser = await puppeteer.launch({ headless: false, slowMo: 80, args: ['–start-fullscreen']
});
    try {
        
        //Open the login page and enter Name and Password for admin
        const page = await browser.newPage();
        await page.goto("https://textileblock-turtlenewton-8080.codio-box.uk/");
        await page.click('a[href="/login"]', { waitUntil: 'networkidle0' })

        await page.type('input[name="username"]', 'admin')
        await page.type('input[name="password"]', 'p455w0rd')
        await page.click('input[type="submit"]', { waitUntil: 'networkidle0' })
        await page.click('a[href="/pupload"]', { waitUntil: 'networkidle0' })
        await page.waitForTimeout(6000);

        // Assert if the Logout is displayed
    await assertEquals((await isElementVisible(page, '//a[text()="Log out"]')),true,'Log out Lable Not Displayed'); // true
    

    // Assert if the Product Name is displayed
    await assertEquals((await isElementVisible(page, '//h2[text()="Upload Your Product"]')),true,'Upload the Product Lable Not Displayed'); // true
    // Assert if the Barcode is displayed
    await assertEquals((await isElementVisible(page, '//h2[text()="Barcode Requires 16 Digits"]')),true,'Barcode Lable Not Displayed'); // true
    // Assert if the Wholesale Price is displayed
    await assertEquals((await isElementVisible(page, '//h4[text()="Wholesale Price"]')),true,'Wholesale Price Lable Not Displayed'); // true

// Assert if the Retail Price is displayed
await assertEquals((await isElementVisible(page, '//h4[text()="Retail Price"]')),true,'Retail Price Lable Not Displayed'); // true

// Assert if the Quantity Price is displayed
await assertEquals((await isElementVisible(page, '//h4[text()="Quantity"]')),true,'Quantity Lable Not Displayed'); // true

// Assert if the Quantity Price is displayed
await assertEquals((await isElementVisible(page, '//div[text()="Image Upload"]')),true,'Image Upload Not Displayed'); // true

              
     }
    catch (error) {
        console.log(error);
    }
    finally {
        await browser.close();
    }
})

async function isElementVisible(page, xPathSelector){
    try {
      await page.waitForXPath(xPathSelector, { visible: true, timeout: 1000 });
      return true;
    } catch {
      return false;
    }
  }
